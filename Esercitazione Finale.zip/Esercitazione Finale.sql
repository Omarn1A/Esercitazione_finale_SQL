CREATE DATABASE ES_Finale_SQL;

-- Creazione tabelle

CREATE TABLE Regions (
    ID INT PRIMARY KEY AUTO_INCREMENT,
    NomeRegione VARCHAR(255) NOT NULL
);

CREATE TABLE Products (
    ID INT PRIMARY KEY AUTO_INCREMENT,
    NomeProdotto VARCHAR(255) NOT NULL,
    Prezzo DECIMAL(10, 2) NOT NULL
);

CREATE TABLE Sales (
    ID INT PRIMARY KEY AUTO_INCREMENT,
    ProdottoID INT,
    RegioneID INT,
    Quantita INT,
    Prezzo_unitario DECIMAL(10, 2),
    Totale DECIMAL(10, 2),
    DataVendita DATE
);

-- Popolazione tabelle

INSERT INTO regions (NomeRegione) VALUES
    ('Lombardia'),
    ('Lazio'),
    ('Campania'),
    ('Sicilia'),
    ('Veneto'),
    ('Toscana'),
    ('Piemonte'),
    ('Emilia-Romagna'),
    ('Calabria'),
    ('Puglia'),
    ('Abruzzo'),
    ('Umbria'),
    ('Marche'),
    ('Sardegna'),
    ('Friuli-Venezia Giulia'),
    ('Basilicata'),
    ('Valle d''Aosta'),
    ('Molise'),
    ('Trentino-Alto Adige'),
    ('Liguria');

INSERT INTO products (NomeProdotto, Prezzo) VALUES
    ('Barbie', 19.99),
    ('Ken', 12.99),
    ('Gigi', 49.99),
    ('Aeroplanino', 79.99),
    ('Lego Castello', 59.99),
    ('Millenium Falcon', 699);


INSERT INTO sales (ProdottoID, RegioneID, Quantita, Prezzo_unitario, Totale, DataVendita) VALUES
    (2, 12, 1, 12.99, 12.99, '2022-01-11'),
    (3, 13, 2, 49.99, 99.98, '2022-03-15'),
    (4, 14, 1, 79.99, 79.99, '2022-07-19'),
    (5, 15, 4, 59.99, 239.96, '2022-08-08'),
    (1, 1, 2, 19.99, 39.98, '2022-10-02'),
    (2, 2, 1, 12.99, 12.99, '2022-12-01'),
    (1, 1, 5, 19.99, 99.95, '2023-02-22'),
    (2, 2, 3, 12.99, 38.97, '2023-04-01'),
    (3, 3, 1, 49.99, 49.99, '2023-08-14'),
    (4, 4, 2, 79.99, 159.98, '2023-09-19'),
    (5, 5, 3, 59.99, 179.97, '2023-10-18'),
    (1, 11, 3, 19.99, 59.97, '2023-12-12');

-- Richieste esercizio
-- Punto 1.1
SELECT ID, COUNT(*)
FROM products
GROUP BY ID
HAVING COUNT(*) > 1;
-- Punto 1.2
SELECT ID, COUNT(*)
FROM regions
GROUP BY ID
HAVING COUNT(*) > 1;
-- Punto 1.3
SELECT ID, COUNT(*)
FROM sales
GROUP BY ID
HAVING COUNT(*) > 1;
-- Punto 2
SELECT 
products.NomeProdotto, SUM(sales.totale) AS Fatturato_prodotto 
FROM 
products 
INNER JOIN 
sales
ON 
products.ID=sales.ProdottoID 
GROUP BY 
products.NomeProdotto;
-- Punto 3
SELECT 
regions.NomeRegione, SUM(sales.totale) AS Fatturato_prodotto, YEAR(sales.DataVendita) AS Anno
FROM 
sales
INNER JOIN 
regions
ON 
sales.RegioneID=regions.ID
GROUP BY 
regions.NomeRegione, Anno
ORDER BY 
Anno, Fatturato_prodotto 
DESC;
-- Punto 4.1
SELECT 
products.NomeProdotto, SUM(sales.Quantita) AS Vendite
FROM 
products 
INNER JOIN 
sales
ON 
products.ID=sales.ProdottoID
GROUP BY 
products.NomeProdotto 
ORDER BY 
Vendite 
DESC;
-- Punto 4.2
SELECT 
products.NomeProdotto, SUM(sales.Quantita) AS Vendite
FROM 
products 
INNER JOIN
sales
ON 
products.ID=sales.ProdottoID
GROUP BY 
products.NomeProdotto 
ORDER BY 
Vendite 
DESC LIMIT 1;
-- Punto 5.1
SELECT 
* 
FROM sales 
where ProdottoID 
NOT IN (SELECT ID FROM products);
-- Punto 5.2
SELECT DISTINCT 
products.ID 
FROM products 
LEFT OUTER JOIN 
sales
ON  
products.ID=sales.ProdottoID
WHERE 
sales.ProdottoID IS NULL;
-- Punto 6
SELECT
    products.NomeProdotto,
    MAX(sales.DataVendita) AS UltimaDataVendita
FROM
    products
LEFT JOIN
    sales ON products.ID = sales.ProdottoID
GROUP BY
    products.NomeProdotto;



